package cloud.alchemy.fabut;

import cloud.alchemy.fabut.enums.ReferenceCheckType;
import cloud.alchemy.fabut.graph.NodesList;
import cloud.alchemy.fabut.pair.SnapshotPair;
import cloud.alchemy.fabut.property.*;
import cloud.alchemy.fabut.tracking.TrackedObject;
import cloud.alchemy.fabut.tracking.UsageInstrumentation;
import cloud.alchemy.fabut.tracking.UsageReport;
import cloud.alchemy.fabut.tracking.UsageTracker;
import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.opentest4j.AssertionFailedError;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.stream.Collectors;

import static cloud.alchemy.fabut.ReflectionUtil.*;
import static cloud.alchemy.fabut.enums.AssertionContext.*;
import static cloud.alchemy.fabut.enums.EntityChangeType.*;
import static java.util.Optional.of;

public abstract class Fabut extends Assertions {

    private static final String DOT = ".";

    /**
     * ThreadLocal holding the current Fabut instance for the test thread.
     * This allows generated assertion builders to access Fabut without requiring
     * explicit passing of 'this'.
     */
    private static final ThreadLocal<Fabut> CURRENT = new ThreadLocal<>();

    private final Set<Object> pendingBuilders = Collections.newSetFromMap(new IdentityHashMap<>());

    /**
     * Get the current Fabut instance for this thread.
     * @return the current Fabut instance
     * @throws IllegalStateException if no Fabut instance is set (test not properly initialized)
     */
    public static Fabut current() {
        Fabut instance = CURRENT.get();
        if (instance == null) {
            throw new IllegalStateException(
                "No Fabut instance available. Ensure your test class extends Fabut and @BeforeEach has run.");
        }
        return instance;
    }

    public void registerPendingVerification(Object builder) {
        pendingBuilders.add(builder);
    }

    public void markVerified(Object builder) {
        pendingBuilders.remove(builder);
    }

    protected final Queue<Class<?>> entityTypes = new ConcurrentLinkedQueue<>();
    protected final Queue<Class<?>> complexTypes = new ConcurrentLinkedQueue<>();
    protected final Queue<Class<?>> ignoredTypes = new ConcurrentLinkedQueue<>();
    protected final Queue<Class<?>> trackedTypes = new ConcurrentLinkedQueue<>();
    protected final Map<Class<?>, List<String>> ignoredFields = new ConcurrentHashMap<>();

    /**
     * Minimum usage threshold percentage (0-100). When set to a value > 0,
     * tests will fail if any tracked class has average field usage below this threshold.
     * Default is -1 (disabled, report only).
     *
     * Set in constructor: {@code usageThreshold = 50;} to fail if usage drops below 50%.
     */
    protected double usageThreshold = -1;

    /**
     * Controls whether usage tracking is enabled. When set to false,
     * takeSnapshot() will still work for snapshot assertions but will not
     * instrument classes or track field access.
     * Default is true (tracking enabled).
     *
     * Set in constructor: {@code trackUsage = false;} to disable tracking.
     */
    protected boolean trackUsage = true;

    private UsageTracker usageTracker;

    /**
     * Returns the current usage tracker instance. Available after @BeforeEach.
     */
    protected UsageTracker getUsageTracker() {
        return usageTracker;
    }

    /**
     * Pauses usage tracking. Call after the API under test returns,
     * so that field access during assertions is not recorded as real usage.
     *
     * Example:
     * <pre>
     * takeSnapshot();
     * Order order = orderService.create(customerId, items);
     * pauseTracking();
     * OrderAssert.created(order).status_is("PENDING").verify();
     * </pre>
     */
    protected void pauseTracking() {
        if (usageTracker != null && usageTracker.isActive()) {
            usageTracker.pause();
        }
    }

    /**
     * Determines whether an object should be tracked for usage analysis.
     * Override to filter out objects like uninitialized Hibernate proxies.
     *
     * Example:
     * <pre>
     * protected boolean shouldTrackObject(Object obj) {
     *     return Hibernate.isInitialized(obj);
     * }
     * </pre>
     *
     * @param obj the object being registered for tracking
     * @return true if the object should be tracked, false to skip it
     */
    protected boolean shouldTrackObject(Object obj) {
        return true;
    }
    private final Map<Class<?>, Map<Object, CopyAssert>> dbSnapshot = Collections.synchronizedMap(new LinkedHashMap<>());
    final List<SnapshotPair> parameterSnapshot = new ArrayList<>();

    // Performance caches
    private enum TypeCategory { ENTITY, COMPLEX, IGNORED }
    private final Map<Class<?>, EnumSet<TypeCategory>> typeCategoriesCache = new ConcurrentHashMap<>();
    private final Map<Class<?>, List<Method>> sortedMethodsCache = new ConcurrentHashMap<>();
    private final Map<String, String> upperUnderscoredCache = new ConcurrentHashMap<>();

    protected void customAssertEquals(Object expected, Object actual) {
        assertEquals(expected, actual);
    }

    protected List<?> findAll(final Class<?> entityClass) {
        throw new IllegalStateException("Override findAll method");
    }

    protected Object findById(final Class<?> entityClass, final Object id) {
        throw new IllegalStateException("Override findById method");
    }

    /**
     * Refreshes a Hibernate proxy by loading the actual entity from database.
     * If the value is not a proxy or is already initialized, returns as-is.
     * Uses reflection to avoid direct Hibernate dependency.
     *
     * @param value the value that might be a lazy proxy
     * @return the refreshed entity or the original value
     */
    protected Object refreshIfProxy(final Object value) {
        return value;
    }

    /**
     * Generates a unique, human-readable path/identifier for an entity.
     * Override this method to provide meaningful entity identification in error messages.
     * <p>
     * Example implementations:
     * <pre>
     * // Simple: class name + ID
     * return entity.getClass().getSimpleName() + "#" + getIdValue(entity);
     *
     * // With business key
     * if (entity instanceof User user) {
     *     return "User[id=" + user.getId() + ", email=" + user.getEmail() + "]";
     * }
     * </pre>
     *
     * @param entity The entity to identify
     * @return A unique, readable identifier for the entity
     */
    protected String entityPath(final Object entity) {
        if (entity == null) {
            return "null";
        }
        if (isEntityType(entity.getClass())) {
            final String className = getRealClass(entity.getClass()).getSimpleName();
            final Object id = getIdValue(entity);
            return className + "[id=" + (id != null ? id : "null") + "]";
        }
        return entity.toString();
    }

    /**
     * Formats a value for display in assertion failure messages.
     * Handles Optional containing entities by using entityPath format.
     */
    private String formatValue(final Object value) {
        if (value == null) {
            return "null";
        }
        if (value instanceof Optional<?> opt) {
            if (opt.isEmpty()) {
                return "Optional.empty";
            }
            Object inner = opt.get();
            if (isEntityType(inner.getClass())) {
                return "Optional[" + entityPath(inner) + "]";
            }
            return value.toString();
        }
        if (isEntityType(value.getClass())) {
            return entityPath(value);
        }
        return String.valueOf(value);
    }

    @BeforeEach
    public void before() {
        CURRENT.set(this);
        pendingBuilders.clear();
        parameterSnapshot.clear();
        dbSnapshot.clear();
        for (final Class<?> entityType : entityTypes) {
            // Use ConcurrentHashMap for thread-safe parallel snapshot taking
            dbSnapshot.put(entityType, new ConcurrentHashMap<>());
        }
        if (trackUsage) {
            usageTracker = new UsageTracker();
            usageTracker.setIgnoredFields(ignoredFields);
            usageTracker.setTrackingFilter(this::shouldTrackObject);
            UsageTracker.setCurrent(usageTracker);
        }
    }

    @AfterEach
    public void after() {
        try {
            final FabutReport report = new FabutReport(() -> "After test assert");

            if (!pendingBuilders.isEmpty()) {
                int count = pendingBuilders.size();
                pendingBuilders.clear();
                throw new AssertionFailedError(
                        "UNVERIFIED BUILDER: created " + count
                        + " assertion builder(s) without calling verify()");
            }

            final FabutReport paremeterReport = report.getSubReport(() -> "Parameter snapshot test report");
            assertParameterSnapshot(paremeterReport);

            final FabutReport snapshotReport = report.getSubReport(() -> "Repository snapshot assert");
            assertDbSnapshot(snapshotReport);

            if (!report.isSuccess()) {
                throw new AssertionFailedError(report.getMessage());
            }
        } finally {
            try {
                if (usageTracker != null && usageTracker.isActive()) {
                    UsageReport usageReport = usageTracker.getReport();
                    if (usageReport.hasTrackedObjects()) {
                        System.out.println(usageReport.generate());

                        // Print never-accessed objects individually for traceability
                        var neverAccessed = usageReport.getNeverAccessedObjects();
                        if (!neverAccessed.isEmpty()) {
                            var naSb = new StringBuilder();
                            naSb.append("  WARNING: ").append(neverAccessed.size())
                                    .append(neverAccessed.size() == 1 ? " object" : " objects")
                                    .append(" fetched but never accessed:\n");
                            for (var tracked : neverAccessed) {
                                Object ref = tracked.getObjectRef();
                                naSb.append("    ").append(ref != null ? entityPath(ref) : tracked.getObjectClass().getSimpleName()).append("\n");
                            }
                            System.out.println(naSb.toString().stripTrailing());
                        }

                        // Enforce threshold if configured
                        if (usageThreshold > 0) {
                            var violations = usageReport.getViolations(usageThreshold);
                            if (!violations.isEmpty()) {
                                var sb = new StringBuilder();
                                sb.append("USAGE THRESHOLD VIOLATION: minimum ").append(String.format("%.0f%%", usageThreshold)).append(" required\n");
                                for (var v : violations) {
                                    sb.append("  ").append(v.className())
                                            .append(": ").append(String.format("%.0f%%", v.averageUsagePercent()))
                                            .append(" avg usage (").append(v.instanceCount())
                                            .append(v.instanceCount() == 1 ? " instance)" : " instances)");
                                    if (!v.commonUnusedFields().isEmpty()) {
                                        sb.append(" — unused: ").append(String.join(", ", v.commonUnusedFields()));
                                    }
                                    sb.append("\n");
                                }
                                throw new AssertionFailedError(sb.toString().stripTrailing());
                            }
                        }
                    }
                    usageTracker.deactivate();
                }
            } finally {
                UsageTracker.removeCurrent();
                CURRENT.remove();
            }
        }
    }

    // COMMANDS
    public void takeSnapshot(final Object... parameters) {
        final FabutReport report = new FabutReport(() -> "Take snapshot");
        takeSnapshott(report, parameters);

        if (!report.isSuccess()) {
            throw new AssertionFailedError(report.getMessage());
        }

        // Activate usage tracking after snapshot is taken
        if (trackUsage) {
            instrumentTrackedTypes();
            if (usageTracker != null) {
                usageTracker.activate();
            }
        }
    }

    /**
     * Instruments all registered types for usage tracking via ByteBuddy.
     * Called once per test when takeSnapshot() is invoked.
     */
    private void instrumentTrackedTypes() {
        Set<Class<?>> all = new LinkedHashSet<>();
        all.addAll(entityTypes);
        all.addAll(complexTypes);
        all.addAll(trackedTypes);
        UsageInstrumentation.instrumentClasses(all);
    }

    public void assertObject(final String message, final Object object, final IProperty... properties) {

        final FabutReport report = new FabutReport(() -> message + ": " + entityPath(object));

        if (!isComplexType(object.getClass()) && !isEntityType(object.getClass())) {
            throw new IllegalStateException("Unsupported object type" + object.getClass() + " " + object);
        }

        if (isEntityType(object.getClass()) && doesExistInSnapshot(object)) {
            report.entityInSnapshot(object);
            throw new AssertionFailedError(report.getMessage());
        }

        assertObjectWithProperties(report, object, extractProperties(properties));

        if (!report.isSuccess()) {
            throw new AssertionFailedError(report.getMessage());
        }
    }

    public void assertObject(final Object expected, final IProperty... properties) {
        String label = isEntityType(expected.getClass()) ? "CREATED" : "Asserting object";
        assertObject(label, expected, properties);
    }

    public <T> T assertEntityWithSnapshot(final T entity, final IProperty... expectedChanges) {
        checkIfEntity(entity);
        final FabutReport report = new FabutReport(() -> "Assert with snapshot: " + entityPath(entity));

        if (expectedChanges.length == 0) {
            report.assertWithSnapshotMustHaveAtLeastOnChange(entity);
            throw new AssertionFailedError(report.getMessage());
        }

        final Object freshEntity = assertEntityWithSnapshot(report, entity, extractProperties(expectedChanges));

        if (!report.isSuccess()) {
            throw new AssertionFailedError(report.getMessage());
        }

        return (T) freshEntity;
    }

    public void assertEntityAsDeleted(final Object entity) {
        checkIfEntity(entity);

        final FabutReport report = new FabutReport(() -> "Assert entity as deleted: " + entityPath(entity));
        assertEntityAsDeleted(report, entity);
        if (!report.isSuccess()) {
            throw new AssertionFailedError(report.getMessage());
        }
    }

    public void ignoreEntity(final Object entity) {
        checkIfEntity(entity);

        final FabutReport report = new FabutReport(() -> "Ignore entity");
        ignoreEntity(report, entity);
        if (!report.isSuccess()) {
            throw new AssertionFailedError(report.getMessage());
        }
    }

    // ==================== String-based assertion methods (used by generated builders) ====================

    /**
     * Assert field equals expected value.
     */
    public <T> Property<T> value(final String path, final T expectedValue) {
        return new Property<>(path, expectedValue);
    }

    /**
     * Ignore field in assertion.
     */
    public IgnoredProperty ignored(final String path) {
        return new IgnoredProperty(path);
    }

    /**
     * Assert field is not null.
     */
    public NotNullProperty notNull(final String path) {
        return new NotNullProperty(path);
    }

    /**
     * Assert field is null.
     */
    public NullProperty isNull(final String path) {
        return new NullProperty(path);
    }

    /**
     * Assert Optional field is not empty.
     */
    public NotEmptyProperty notEmpty(final String path) {
        return new NotEmptyProperty(path);
    }

    /**
     * Assert Optional field is empty.
     */
    public EmptyProperty isEmpty(final String path) {
        return new EmptyProperty(path);
    }

    /**
     * Assert multiple fields are not null (varargs).
     */
    public MultiProperties notNull(final String... paths) {
        final List<ISingleProperty> properties = new ArrayList<>(paths.length);
        for (String path : paths) {
            properties.add(notNull(path));
        }
        return new MultiProperties(properties);
    }

    /**
     * Assert multiple fields are null (varargs).
     */
    public MultiProperties isNull(final String... paths) {
        final List<ISingleProperty> properties = new ArrayList<>(paths.length);
        for (String path : paths) {
            properties.add(isNull(path));
        }
        return new MultiProperties(properties);
    }

    /**
     * Ignore multiple fields (varargs).
     */
    public MultiProperties ignored(final String... paths) {
        final List<ISingleProperty> properties = new ArrayList<>(paths.length);
        for (String path : paths) {
            properties.add(ignored(path));
        }
        return new MultiProperties(properties);
    }

    // ==================== PropertyPath-based methods (v4 backward compatibility) ====================

    /**
     * Assert field equals expected value.
     * @deprecated Use {@link #value(String, Object)} instead
     */
    @Deprecated
    public <T> Property<T> value(final PropertyPath<T> path, final T expectedValue) {
        return new Property<>(path.getPath(), expectedValue);
    }

    /**
     * Ignore field in assertion.
     * @deprecated Use {@link #ignored(String)} instead
     */
    @Deprecated
    public IgnoredProperty ignored(final PropertyPath<?> path) {
        return new IgnoredProperty(path.getPath());
    }

    /**
     * Ignore multiple fields.
     * @deprecated Use {@link #ignored(String...)} instead
     */
    @Deprecated
    public MultiProperties ignored(final PropertyPath<?>... paths) {
        final List<ISingleProperty> properties = new ArrayList<>(paths.length);
        for (final PropertyPath<?> path : paths) {
            properties.add(ignored(path));
        }
        return new MultiProperties(properties);
    }

    /**
     * Assert field is not null.
     * @deprecated Use {@link #notNull(String)} instead
     */
    @Deprecated
    public NotNullProperty notNull(final PropertyPath<?> path) {
        return new NotNullProperty(path.getPath());
    }

    /**
     * Assert multiple fields are not null.
     * @deprecated Use {@link #notNull(String...)} instead
     */
    @Deprecated
    public MultiProperties notNull(final PropertyPath<?>... paths) {
        final List<ISingleProperty> properties = new ArrayList<>(paths.length);
        for (final PropertyPath<?> path : paths) {
            properties.add(notNull(path));
        }
        return new MultiProperties(properties);
    }

    /**
     * Assert field is null.
     * @deprecated Use {@link #isNull(String)} instead
     */
    @Deprecated
    public NullProperty isNull(final PropertyPath<?> path) {
        return new NullProperty(path.getPath());
    }

    /**
     * Assert multiple fields are null.
     * @deprecated Use {@link #isNull(String...)} instead
     */
    @Deprecated
    public MultiProperties isNull(final PropertyPath<?>... paths) {
        final List<ISingleProperty> properties = new ArrayList<>(paths.length);
        for (final PropertyPath<?> path : paths) {
            properties.add(isNull(path));
        }
        return new MultiProperties(properties);
    }

    /**
     * Assert Optional field is not empty.
     * @deprecated Use {@link #notEmpty(String)} instead
     */
    @Deprecated
    public NotEmptyProperty notEmpty(final PropertyPath<?> path) {
        return new NotEmptyProperty(path.getPath());
    }

    /**
     * Assert multiple Optional fields are not empty.
     * @deprecated Use String-based API instead
     */
    @Deprecated
    public MultiProperties notEmpty(final PropertyPath<?>... paths) {
        final List<ISingleProperty> properties = new ArrayList<>(paths.length);
        for (final PropertyPath<?> path : paths) {
            properties.add(notEmpty(path));
        }
        return new MultiProperties(properties);
    }

    /**
     * Assert Optional field is empty.
     * @deprecated Use {@link #isEmpty(String)} instead
     */
    @Deprecated
    public EmptyProperty isEmpty(final PropertyPath<?> path) {
        return new EmptyProperty(path.getPath());
    }

    /**
     * Assert multiple Optional fields are empty.
     * @deprecated Use String-based API instead
     */
    @Deprecated
    public MultiProperties isEmpty(final PropertyPath<?>... paths) {
        final List<ISingleProperty> properties = new ArrayList<>(paths.length);
        for (final PropertyPath<?> path : paths) {
            properties.add(isEmpty(path));
        }
        return new MultiProperties(properties);
    }

    // TYPE METHODS
    private void checkIfEntity(final Object entity) {
        if (entity == null) {
            throw new IllegalStateException("assertEntityWithSnapshot cannot take null entity!");
        }

        if (!isEntityType(entity.getClass())) {
            throw new IllegalStateException(entity.getClass() + " is not registered as entity type");
        }
    }

    private EnumSet<TypeCategory> getTypeCategories(Class<?> clazz) {
        return typeCategoriesCache.computeIfAbsent(getRealClass(clazz), this::computeTypeCategories);
    }

    private EnumSet<TypeCategory> computeTypeCategories(Class<?> c) {
        EnumSet<TypeCategory> categories = EnumSet.noneOf(TypeCategory.class);
        if (isOneOfType(c, ignoredTypes)) categories.add(TypeCategory.IGNORED);
        if (isOneOfType(c, entityTypes)) categories.add(TypeCategory.ENTITY);
        if (isOneOfType(c, complexTypes)) categories.add(TypeCategory.COMPLEX);
        return categories;
    }

    protected boolean isEntityType(Class<?> clazz) {
        return getTypeCategories(clazz).contains(TypeCategory.ENTITY);
    }

    protected boolean isComplexType(Class<?> clazz) {
        return getTypeCategories(clazz).contains(TypeCategory.COMPLEX);
    }

    protected boolean isIgnoredType(Class<?> clazz) {
        return getTypeCategories(clazz).contains(TypeCategory.IGNORED);
    }

    private boolean isIgnoredField(Class<?> clazz, String fieldName) {
        List<String> fields = ignoredFields.get(getRealClass(clazz));
        return fields != null && fields.contains(fieldName);
    }

    // PROPERTIES
    private List<Method> getGetMethods(final Object object) {
        final Class<?> clazz = object.getClass();
        return sortedMethodsCache.computeIfAbsent(clazz, c -> {
            final List<Method> getMethods = new ArrayList<>();
            final List<Method> getMethodsComplexType = new ArrayList<>();
            final boolean isEntityClass = isEntityType(c);
            final boolean isComplexOrEntity = isComplexType(c) || isEntityClass;

            final Collection<Method> allGetMethods = ReflectionUtil.getMethods(c).values();

            for (final Method method : allGetMethods) {
                if (!(isEntityClass && isCollectionClass(method.getReturnType()))) {
                    // complex or entity type get methods inside object come last in list,
                    // this is important because otherwise inner object asserts will possibly 'eat up' expected properties of parent object during asserts
                    if (isComplexOrEntity) {
                        getMethodsComplexType.add(method);
                    } else {
                        getMethods.add(method);
                    }
                }
            }
            getMethods.addAll(getMethodsComplexType);
            return getMethods;
        });
    }

    List<ISingleProperty> removeParentQualification(final String parentPropertyName, final List<ISingleProperty> properties) {

        final String parentPrefix = parentPropertyName + DOT;
        for (final ISingleProperty property : properties) {
            final String path = StringUtils.removeStart(property.getPath(), parentPrefix);
            property.setPath(path);
        }
        return properties;
    }

    ISingleProperty obtainProperty(final Object field, final String propertyPath, final List<ISingleProperty> properties) {

        final ISingleProperty property = getPropertyFromList(propertyPath, properties);
        if (property != null) {
            return property;
        }
        return value(propertyPath, field);
    }

    ISingleProperty getPropertyFromList(final String propertyPath, final List<ISingleProperty> properties) {

        final Iterator<ISingleProperty> iterator = properties.iterator();
        while (iterator.hasNext()) {
            final ISingleProperty property = iterator.next();
            if (property.getPath().equalsIgnoreCase(propertyPath)) {
                iterator.remove();
                return property;
            }
        }
        return null;
    }

    ReferenceCheckType checkByReference(final FabutReport report, Object expected, Object actual, final List<ObjectMethod> parents) {

        if (expected == actual) {
            // report.asserted(pair, propertyName);
            return ReferenceCheckType.EQUAL_REFERENCE;
        }

        if (expected == null ^ actual == null) {
            final List<String> propertyNames = parents.stream().map(ObjectMethod::property).toList();
            final String propertyName = propertyNames.getLast();
            report.assertFailFormatted(propertyName, () -> formatValue(expected), () -> formatValue(actual));
            return ReferenceCheckType.EXCLUSIVE_NULL;
        }
        return ReferenceCheckType.NOT_NULL_PAIR;
    }

    List<ISingleProperty> extractProperties(final IProperty... properties) {
        final ArrayList<ISingleProperty> list = new ArrayList<>();

        for (final IProperty property : properties) {
            switch (property) {
                case ISingleProperty single -> list.add(single);
                case IMultiProperties multi -> list.addAll(multi.getProperties());
                case null, default -> {}
            }
        }

        return list;
    }

    List<ISingleProperty> extractPropertiesWithMatchingParent(final String parent, final List<ISingleProperty> properties) {

        final String parentPrefix = parent + DOT;
        final List<ISingleProperty> extracts = new ArrayList<>();
        final Iterator<ISingleProperty> iterator = properties.iterator();
        while (iterator.hasNext()) {
            final ISingleProperty property = iterator.next();
            final String path = property.getPath();
            if (path.startsWith(parentPrefix) || path.equalsIgnoreCase(parent)) {
                extracts.add(property);
                iterator.remove();
            }
        }
        return extracts;
    }

    boolean hasInnerProperties(final String parent, final List<ISingleProperty> properties) {

        final String parentPrefix = parent + DOT;
        for (final ISingleProperty property : properties) {
            if (property.getPath().startsWith(parentPrefix)) {
                return true;
            }
        }
        return false;
    }

    // COPY
    protected Object createCopyObject(final Object object, final NodesList nodes) throws CopyException {

        Object copy = nodes.getExpected(object);
        if (copy != null) {
            return copy;
        }

        try {
            copy = createEmptyCopyOf(object);
        } catch (NoSuchMethodException | InvocationTargetException | InstantiationException | IllegalAccessException e) {
            throw new CopyException(object.getClass().getSimpleName());
        }

        nodes.addPair(copy, object);

        final boolean isEntityType = isEntityType(object.getClass());

        final Class<?> classObject = object.getClass();
        final Collection<Method> allGetMethods = getMethods(classObject).values();

        for (final Method getMethod : allGetMethods) {
            if (getMethod.getParameterAnnotations().length == 0 && !(isEntityType && isCollectionClass(getMethod.getReturnType()))) {

                final String getMethodName = getMethod.getName();
                final String fieldName = getFieldNameOfGet(getMethod);

                final Field objectField = findAccessibleField(object, fieldName);

                final String setMethodName = SET_METHOD_PREFIX + getMethodName.substring(3);
                final Method setMethod = findSetMethod(copy, setMethodName);

                final Field copyField = findAccessibleField(copy, fieldName);

                if (setMethod == null) {
                    throw new CopyException(object.getClass().getSimpleName());
                }

                Object value;
                try {
                    value = getMethod.invoke(object);
                } catch (InvocationTargetException | IllegalAccessException e) {
                    throw new CopyException(object.getClass().getSimpleName());
                }

                try {
                    if (getMethodName.equals(GET_ID)) {
                        setMethod.invoke(copy, value);
                    } else if (value != null && isOptionalType(value.getClass()) && !isOptionalType(objectField.getType())) {
                        copyField.set(copy, ((Optional<?>) value).orElse(null));
                    } else {
                        copyField.set(copy, value);
                    }
                } catch (InvocationTargetException | IllegalAccessException e) {
                    throw new CopyException(object.getClass().getSimpleName());
                }
            }
        }

        return copy;
    }

    protected Object createEmptyCopyOf(final Object object)
            throws NoSuchMethodException, InvocationTargetException, InstantiationException, IllegalAccessException {
        return object.getClass().getConstructor().newInstance();
    }

    protected Object copyProperty(final Object propertyForCopying, final NodesList nodes) throws CopyException {
        if (propertyForCopying == null) {
            // its null we shouldn't do anything
            return null;
        }

        if (isComplexType(propertyForCopying.getClass())) {
            // its complex object, we need its copy
            return createCopyObject(propertyForCopying, nodes);
        }

        if (isEntityType(propertyForCopying.getClass())) {
            // its entity object, we need its copy
            if (hasIdMethod(propertyForCopying)) {
                return createCopyObject(propertyForCopying, nodes);
            } else {
                return propertyForCopying;
            }
        }

        if (isListType(propertyForCopying.getClass())) {
            // just creating new list with same elements
            return copyList((List<?>) propertyForCopying, nodes);
        }

        if (isOptionalType(propertyForCopying.getClass())) {
            // just creating new list with same elements
            return copyOptional((Optional<?>) propertyForCopying, nodes);
        }

        if (isSetType(propertyForCopying.getClass())) {
            // just creating new set with same elements
            return copySet((Set<?>) propertyForCopying, nodes);
        }

        if (isMapType(propertyForCopying.getClass())) {
            return copyMap((Map<?, ?>) propertyForCopying, nodes);
        }

        // if its not list or some complex type same object will be added.
        return propertyForCopying;
    }

    private Object copyMap(final Map<?, ?> propertyForCopying, NodesList nodes) throws CopyException {

        final Map<Object, Object> mapCopy = new HashMap<>();
        for (final Object key : propertyForCopying.keySet()) {
            mapCopy.put(key, copyProperty(propertyForCopying.get(key), nodes));
        }
        return mapCopy;
    }

    private <T> List<T> copyList(final List<T> list, NodesList nodes) throws CopyException {
        final List<T> copyList = new ArrayList<>();
        for (final T t : list) {
            copyList.add((T) copyProperty(t, nodes));
        }
        return copyList;
    }

    private <T> Optional<T> copyOptional(final Optional<T> optional, NodesList nodes) throws CopyException {

        if (optional.isPresent()) {
            return of((T) copyProperty(optional.get(), nodes));
        } else {
            return Optional.empty();
        }
    }

    private <T> Set<T> copySet(final Set<T> set, NodesList nodes) throws CopyException {

        final Set<T> copySet = new HashSet<>();
        for (final T t : set) {
            copySet.add((T) copyProperty(t, nodes));
        }
        return copySet;
    }

    // ASSERT
    private void assertEntityPair(
            final FabutReport report,
            final List<ObjectMethod> parents,
            Object expected,
            Object actual,
            final List<ISingleProperty> properties,
            final NodesList nodesList) {

        if (!parents.isEmpty()) {
            final List<String> propertyNames = parents.stream().map(ObjectMethod::property).toList();
            final String propertyName = propertyNames.getLast();
            assertEntityById(report, propertyName, expected, actual);
        } else {
            assertSubfields(report, Collections.emptyList(), expected, actual, properties, nodesList);
        }
    }

    void assertEntityAsDeleted(final FabutReport report, final Object entity) {

        ignoreEntity(report, entity);

        final Object findById = findById(entity.getClass(), getIdValue(entity));
        final boolean isDeletedInRepository = findById == null;

        if (!isDeletedInRepository) {
            report.notDeletedInRepository(entity);
        }
    }

    void ignoreEntity(final FabutReport report, final Object entity) {
        markAsAsserted(report, entity);
    }

    Object assertEntityWithSnapshot(final FabutReport report, final Object entity, final List<ISingleProperty> properties) {

        final Object id = getIdValue(entity);
        final Class<?> entityClass = getRealClass(entity.getClass());

        final Map<Object, CopyAssert> map = dbSnapshot.get(entityClass);
        final CopyAssert copyAssert = map != null ? map.get(id) : null;

        if (copyAssert != null) {
            final Object expected = copyAssert.getEntity();
            final Object freshEntity = findById(entityClass, id);
            assertObjects(report, expected, freshEntity, properties);
            return freshEntity;
        } else {
            report.noEntityInSnapshot(entity);
            return null;
        }
    }

    void afterAssertObject(final FabutReport report, final Object object) {
        if (isEntityType(object.getClass())) {
            markAsAsserted(report, object);
        }
    }

    private void assertEntityById(final FabutReport report, final String propertyName, Object expected, Object actual) {

        final Object expectedId = ReflectionUtil.getIdValue(expected);
        final Object actualId = ReflectionUtil.getIdValue(actual);
        try {
            customAssertEquals(expectedId, actualId);
        } catch (final AssertionError e) {
            report.assertFailFormatted(propertyName, () -> formatValue(expected), () -> formatValue(actual));
        }
    }

    void assertObjectWithProperties(final FabutReport report, final Object actual, final List<ISingleProperty> expectedProperties) {

        if (actual == null) {
            report.nullReference();
            return;
        }

        final List<Method> methods = getGetMethods(actual);
        // Reusable empty list and NodesList to avoid repeated allocations
        final List<ObjectMethod> emptyParents = Collections.emptyList();
        // Collect available field names for fuzzy matching on excess properties
        final List<String> availableFieldNames = new ArrayList<>();

        for (final Method method : methods) {

            final String fieldName = ReflectionUtil.getFieldNameOfGet(method);
            final boolean ignoredField = isIgnoredField(actual.getClass(), fieldName);

            if (!ignoredField) {
                availableFieldNames.add(fieldName);
            }

            final ISingleProperty property = getPropertyFromList(fieldName, expectedProperties);
            try {
                if (property != null) {
                    // Cache the invocation result - avoid calling invoke() multiple times
                    final Object fieldValue = method.invoke(actual);
                    assertProperty(report, emptyParents, fieldName, property, fieldValue, expectedProperties, new NodesList());

                    if (expectedProperties.contains(property)) {
                        final FabutReport optimisationReport = new FabutReport();
                        assertProperty(
                                optimisationReport,
                                emptyParents,
                                fieldName,
                                value(fieldName, fieldValue),
                                fieldValue,
                                Collections.emptyList(),
                                new NodesList());

                        if (optimisationReport.isSuccess() && !(property instanceof IgnoredProperty)) {
                            report.notNecessaryAssert(fieldName, actual, fieldValue);
                        }
                    }

                } else if (!ignoredField && hasInnerProperties(fieldName, expectedProperties)) {
                    assertInnerProperty(report, method.invoke(actual), expectedProperties, fieldName);
                } else if (!ignoredField) {
                    // there is no matching property for field
                    report.noPropertyForField(actual, fieldName, method.invoke(actual));
                }
            } catch (final IllegalAccessException | InvocationTargetException e) {
                report.uncallableMethod(method, actual);
            }
        }

        if (!expectedProperties.isEmpty()) {
            for (ISingleProperty singleProperty : expectedProperties) {
                report.excessExpectedProperty(singleProperty.getPath(), availableFieldNames);
            }
        }

        afterAssertObject(report, actual);
    }

    void assertInnerProperty(final FabutReport report, final Object actual, final List<ISingleProperty> properties, final String parent) {
        final List<ISingleProperty> extracts = extractPropertiesWithMatchingParent(parent, properties);
        removeParentQualification(parent, extracts);

        assertObjectWithProperties(report, actual, extracts);
    }

    void assertInnerObject(final FabutReport report, final Object expected, final Object actual, final List<ISingleProperty> properties, final String parent) {

        final List<ISingleProperty> extracts = extractPropertiesWithMatchingParent(parent, properties);
        removeParentQualification(parent, extracts);

        assertObjects(report, expected, actual, extracts);
    }

    void assertObjects(final FabutReport report, final Object expected, final Object actual, final List<ISingleProperty> expectedChangedProperties) {

        assertPair(report, Collections.emptyList(), expected, actual, expectedChangedProperties, new NodesList());

        afterAssertObject(report, actual);
    }

    void assertPair(
            final FabutReport report,
            final List<ObjectMethod> parents,
            Object expected,
            Object actual,
            final List<ISingleProperty> properties,
            final NodesList nodesList) {

        final ReferenceCheckType referenceCheck = checkByReference(report, expected, actual, parents);

        if (referenceCheck == ReferenceCheckType.EQUAL_REFERENCE) {
            return;
        }
        if (referenceCheck == ReferenceCheckType.EXCLUSIVE_NULL) {
            return;
        }

        final String propertyName = getLastPropertyName(parents);
        // check if any of the expected/actual object is recurring in nodes list
        switch (nodesList.nodeCheck(expected, actual)) {
            case SINGLE_NODE -> report.checkByReference(propertyName, actual);
            case CONTAINS_PAIR -> {}
            case NEW_PAIR -> {
                nodesList.addPair(expected, actual);
                if (isIgnoredType(expected.getClass())) {
                    report.ignoredType(expected.getClass());

                } else if (isComplexType(expected.getClass())) {
                    assertSubfields(report, parents, expected, actual, properties, nodesList);

                } else if (isEntityType(expected.getClass())) {
                    assertEntityPair(report, parents, expected, actual, properties, nodesList);

                } else if (isListType(expected.getClass()) && isListType(actual.getClass())) {
                    assertList(report, parents, (List<?>) expected, (List<?>) actual, properties);

                } else if (isMapType(expected.getClass()) && isMapType(actual.getClass())) {
                    assertMap(report, parents, (Map<?, ?>) expected, (Map<?, ?>) actual, properties, nodesList);

                } else if (isOptionalType(expected.getClass()) && isOptionalType(actual.getClass())) {
                    assertOptional(report, parents, (Optional<?>) expected, (Optional<?>) actual, properties, nodesList);

                } else {
                    assertPrimitives(report, parents, expected, actual);
                }
            }
        }
    }

    private static final java.util.regex.Pattern CAMEL_CASE_PATTERN =
        java.util.regex.Pattern.compile("(?<=[A-Z])(?=[A-Z][a-z])|(?<=[^A-Z])(?=[A-Z])|(?<=[A-Za-z])(?=[^A-Za-z])");

    private String splitCamelCase(String s, String separator) {
        return CAMEL_CASE_PATTERN.matcher(s).replaceAll(separator);
    }

    private String upperUnderscored(String s) {
        return upperUnderscoredCache.computeIfAbsent(s,
            str -> splitCamelCase(str, "_").toUpperCase());
    }

    private void assertSubfields(
            final FabutReport report,
            final List<ObjectMethod> parents,
            Object expected,
            Object actual,
            final List<ISingleProperty> properties,
            final NodesList nodesList) {

        final ArrayList<ISingleProperty> propertiesCopy = new ArrayList<>(properties);

        final List<Method> getMethods = getGetMethods(expected);

        if (parents.isEmpty()) {
            final String methodName = report.getAssertionContext().getMethodName();
            report.addCode(() -> "\n" + methodName + "(object");
        }

        final String className = getRealClass(actual.getClass()).getSimpleName();

        StringBuilder chainPrefix = new StringBuilder();
        StringBuilder chainPostfix = new StringBuilder();

        final List<ObjectMethod> reversedParents = new ArrayList<>(parents);
        Collections.reverse(reversedParents);

        for (ObjectMethod parent : reversedParents) {
            final String parentClass = getRealClass(parent.parent().getClass()).getSimpleName();
            chainPrefix.insert(0, parentClass + "." + upperUnderscored(parent.property()) + ".chain(");
            chainPostfix.append(")");
        }

        for (final Method expectedMethod : getMethods) {
            final String fieldName = ReflectionUtil.getFieldNameOfGet(expectedMethod);
            if (!isIgnoredField(expected.getClass(), fieldName)) {
                try {
                    // Cache invocation results - avoid calling invoke() multiple times
                    final Object expectedValue = expectedMethod.invoke(expected);
                    final Method actualMethod = findGetMethod(actual, expectedMethod.getName());
                    final Object actualValue = actualMethod.invoke(actual);

                    // For ENTITY_WITH_SNAPSHOT, only add CODE for changed properties
                    final boolean isSnapshotContext = report.getAssertionContext() == ENTITY_WITH_SNAPSHOT;
                    boolean valuesEqual;
                    try {
                        valuesEqual = Objects.equals(expectedValue, actualValue);
                    } catch (Exception e) {
                        // Handle LazyInitializationException and similar - refresh proxies and retry
                        try {
                            Object refreshedExpected = refreshIfProxy(expectedValue);
                            Object refreshedActual = refreshIfProxy(actualValue);
                            valuesEqual = Objects.equals(refreshedExpected, refreshedActual);
                        } catch (Exception e2) {
                            // Still failing (nested proxies) - treat as not equal
                            valuesEqual = false;
                        }
                    }

                    if (!isSnapshotContext || !valuesEqual) {
                        // Cache refreshed value for code generation
                        final Object refreshedValue = refreshIfProxy(expectedValue);
                        report.addCode(
                                () -> {
                                    final String propertyPath = chainPrefix + className + "." + upperUnderscored(fieldName) + chainPostfix;
                                    final String code;
                                    if (refreshedValue == null) {
                                        code = ",\nisNull(" + propertyPath + ")";
                                    } else if (refreshedValue.getClass().isAssignableFrom(String.class)) {
                                        code = ",\nvalue(" + propertyPath + ", " + "\"" + refreshedValue + "\"" + ")";
                                    } else if (refreshedValue.getClass().isEnum()) {
                                        code = ",\nvalue(" + propertyPath + ", " + refreshedValue.getClass().getSimpleName() + "." + refreshedValue + ")";
                                    } else if (refreshedValue.getClass().isAssignableFrom(Optional.class) && ((Optional<?>) refreshedValue).isEmpty()) {
                                        code = ",\nisEmpty(" + propertyPath + ")";
                                    } else if (isEntityType(refreshedValue.getClass())) {
                                        code = ",\nvalue(" + propertyPath + ", " + entityPath(refreshedValue) + ")";
                                    } else {
                                        code = ",\nvalue(" + propertyPath + ", " + refreshedValue + ")";
                                    }
                                    return code;
                                });
                    }

                    final ISingleProperty property = obtainProperty(expectedValue, fieldName, properties);
                    assertProperty(report, parents, fieldName, property, actualValue, properties, nodesList);

                    if (propertiesCopy.contains(property)) {
                        final FabutReport optimisationReport = new FabutReport();
                        assertProperty(
                                optimisationReport,
                                parents,
                                fieldName,
                                value(fieldName, expectedValue),
                                actualValue,
                                Collections.emptyList(),
                                new NodesList());

                        if (optimisationReport.isSuccess() && !(property instanceof IgnoredProperty)) {
                            report.notNecessaryAssert(fieldName, actual, actualValue);
                        }
                    }

                } catch (final IllegalAccessException | InvocationTargetException e) {
                    report.uncallableMethod(expectedMethod, actual);
                }
            }
        }

        if (parents.isEmpty()) {
            report.addCode(() -> ");");
        }
    }

    private void assertPrimitives(final FabutReport report, final List<ObjectMethod> parents, Object expected, Object actual) {
        try {
            customAssertEquals(expected, actual);
        } catch (final AssertionError e) {
            final String propertyName = getLastPropertyName(parents);
            report.assertFailFormatted(propertyName, () -> formatValue(expected), () -> formatValue(actual));
        }
    }

    private String getLastPropertyName(List<ObjectMethod> parents) {
        final List<String> propertyNames = parents.stream().map(ObjectMethod::property).toList();
        final String propertyName;
        if (propertyNames.isEmpty()) {
            propertyName = "";
        } else {
            propertyName = propertyNames.getLast();
        }
        return propertyName;
    }

    void assertProperty(
            final FabutReport report,
            List<ObjectMethod> parents,
            final String fieldName,
            final ISingleProperty expected,
            final Object actual,
            final List<ISingleProperty> properties,
            final NodesList nodesList) {

        removeParentQualification(fieldName, properties);

        switch (expected) {
            case NotNullProperty notNullProperty -> {
                if (actual == null) {
                    report.notNullProperty(expected.getPath());
                }
            }
            case NullProperty nullProperty -> {
                if (actual != null) {
                    report.nullProperty(expected.getPath(), actual);
                }
            }
            case NotEmptyProperty notEmptyProperty -> {
                if (!(actual instanceof Optional && ((Optional<?>) actual).isPresent())) {
                    report.notEmptyProperty(expected.getPath(), actual);
                }
            }
            case EmptyProperty emptyProperty -> {
                if (!(actual instanceof Optional && ((Optional<?>) actual).isEmpty())) {
                    report.emptyProperty(expected.getPath(), actual);
                }
            }
            case IgnoredProperty ignoredProperty -> report.reportIgnoreProperty(expected.getPath());
            case Property property -> {
                final Object expectedValue = property.getValue();
                final ArrayList<ObjectMethod> parentsExtended = new ArrayList<>(parents);
                parentsExtended.add(new ObjectMethod(actual, expected.getPath()));
                assertPair(report, parentsExtended, expectedValue, actual, properties, nodesList);
            }
            case null, default -> throw new IllegalStateException();
        }
    }

    void assertList(
            final FabutReport report, final List<ObjectMethod> parents, final List<?> expected, final List<?> actual, final List<ISingleProperty> properties) {

        final String propertyName = getLastPropertyName(parents);

        // check sizes
        if (expected.size() != actual.size()) {
            report.listDifferentSizeComment(propertyName, expected.size(), actual.size());
        } else {
            // assert every element by index

            for (int i = 0; i < actual.size(); i++) {
                report.assertingListElement(propertyName, i);
                assertObjects(report, expected.get(i), actual.get(i), properties);
            }
        }
    }

    void assertMap(
            final FabutReport report,
            final List<ObjectMethod> parents,
            final Map<?, ?> expected,
            final Map<?, ?> actual,
            final List<ISingleProperty> properties,
            final NodesList nodesList) {

        final Set<?> actualKeySet = actual.keySet();
        final Set<?> expectedKeySet = expected.keySet();

        // First pass: assert common keys
        for (final Object key : expectedKeySet) {
            if (actualKeySet.contains(key)) {
                report.assertingMapKey(key);
                assertPair(report, parents, expected.get(key), actual.get(key), properties, nodesList);
            }
        }

        // Report excess actual keys (in actual but not expected)
        for (final Object key : actualKeySet) {
            if (!expectedKeySet.contains(key)) {
                report.excessActualMap(key);
            }
        }
    }

    void assertOptional(
            final FabutReport report,
            List<ObjectMethod> parents,
            Optional<?> expected,
            Optional<?> actual,
            final List<ISingleProperty> properties,
            final NodesList nodesList) {

        if (expected.isEmpty() && actual.isEmpty()) {
            return;
        }

        if (expected.isPresent() ^ actual.isPresent()) {

            final List<String> propertyNames = parents.stream().map(ObjectMethod::property).toList();
            final String propertyName = propertyNames.getLast();

            report.assertFailFormatted(propertyName, () -> formatValue(expected), () -> formatValue(actual));
            return;
        }

        final Object expectedValue = expected.get();
        final Object actualValue = actual.get();

        assertPair(report, parents, expectedValue, actualValue, properties, nodesList);
    }


    // SNAPSHOT
    void takeSnapshott(final FabutReport report, final Object... parameters) {
        // Take parameter snapshots
        for (final Object object : parameters) {
            try {
                final SnapshotPair snapshotPair = new SnapshotPair(object, createCopyObject(object, new NodesList()));
                parameterSnapshot.add(snapshotPair);
            } catch (final CopyException e) {
                report.noCopy(object);
            }
        }

        // Take database snapshots with parallel processing for large datasets
        for (final Map.Entry<Class<?>, Map<Object, CopyAssert>> entry : dbSnapshot.entrySet()) {
            final List<?> findAll = findAll(entry.getKey());
            final Map<Object, CopyAssert> entityMap = entry.getValue();

            if (shouldUseParallelProcessing(findAll.size())) {
                findAll.parallelStream().forEach(entity ->
                    takeSnapshot(entity, entityMap, report));
            } else {
                for (final Object entity : findAll) {
                    takeSnapshot(entity, entityMap, report);
                }
            }
        }
    }

    private void takeSnapshot(Object entity, Map<Object, CopyAssert> entityMap, FabutReport report) {
        try {
            final Object id = getIdValue(entity);  // Only call once
            final Object copy = createCopyObject(entity, new NodesList());
            entityMap.put(id, new CopyAssert(copy));
        } catch (final CopyException e) {
            report.noCopy(entity);
        }
    }

    private Map<Object, Object> getAfterEntities(final Class<?> clazz) {
        final Map<Object, Object> afterEntities = new HashMap<>();
        final List<?> entities = findAll(clazz);
        for (final Object entity : entities) {
            final Object id = ReflectionUtil.getIdValue(entity);
            if (id != null) {
                afterEntities.put(id, entity);
            }
        }
        return afterEntities;
    }

    private boolean doesExistInSnapshot(final Object entity) {
        final Object id = getIdValue(entity);
        final Class<?> entityClass = entity.getClass();
        final Map<Object, CopyAssert> map = dbSnapshot.get(entityClass);
        return map != null && map.get(id) != null;
    }

    void assertParameterSnapshot(final FabutReport report) {
        for (final SnapshotPair snapshotPair : parameterSnapshot) {
            assertObjects(report.getSubReport(() -> "Snapshot pair assert"), snapshotPair.getExpected(), snapshotPair.getActual(), new ArrayList<>());
        }
    }

    void markAsAsserted(final FabutReport report, final Object entity) {
        final Class<?> actualType = entity.getClass();

        final Object id = getIdValue(entity);
        if (id == null) {
            report.idNull(actualType);
            return;
        }

        markAsserted(id, entity, actualType);
    }

    private void markAsserted(final Object id, final Object copy, final Class<?> actualType) {
        final Map<Object, CopyAssert> map = dbSnapshot.get(getRealClass(actualType));
        CopyAssert copyAssert = map.get(id);
        if (copyAssert == null) {
            copyAssert = new CopyAssert(copy);
            map.put(id, copyAssert);  // Use id parameter directly instead of calling getIdValue again
        }
        copyAssert.setAsserted(true);
    }

    void assertDbSnapshot(final FabutReport report) {
        // assert entities by classes
        for (final Map.Entry<Class<?>, Map<Object, CopyAssert>> snapshotEntry : dbSnapshot.entrySet()) {
            final Map<Object, Object> afterEntities = getAfterEntities(snapshotEntry.getKey());
            final Set<?> beforeIds = new HashSet<>(snapshotEntry.getValue().keySet());
            final Set<?> afterIds = new HashSet<>(afterEntities.keySet());

            checkNotExistingInAfterDbState(beforeIds, afterIds, snapshotEntry.getValue(), report);
            checkNewToAfterDbState(beforeIds, afterIds, afterEntities, report);
            assertDbSnapshotWithAfterState(beforeIds, afterIds, snapshotEntry.getValue(), afterEntities, report);
        }
    }

    void checkNotExistingInAfterDbState(final Set<?> beforeIds, final Set<?> afterIds, final Map<Object, CopyAssert> beforeEntities, final FabutReport report) {
        final Set<?> beforeIdsCopy = new HashSet<>(beforeIds);

        // does difference between db snapshot and after db state
        beforeIdsCopy.removeAll(afterIds);

        // Report deleted entities with enhanced information
        beforeIdsCopy.stream()
                .map(beforeEntities::get)
                .filter(copyAssert -> !copyAssert.isAsserted())
                .map(CopyAssert::getEntity)
                .forEach(entity -> {
                    String path = entityPath(entity);
                    String suggestedFix = String.format("assertEntityAsDeleted(%s);", varName(entity));
                    report.recordEntityChange(DELETED, path, entity.getClass(), null, suggestedFix);
                });
    }

    void checkNewToAfterDbState(final Set<?> beforeIds, final Set<?> afterIds, final Map<Object, Object> afterEntities, final FabutReport report) {
        final Set<?> afterIdsCopy = new HashSet<>(afterIds);

        // does difference between after db state and db snapshot
        afterIdsCopy.removeAll(beforeIds);

        if (afterIdsCopy.isEmpty()) {
            return;
        }

        // Collect all created entities and generate CODE for each
        List<Object> createdEntities = afterIdsCopy.stream()
                .map(afterEntities::get)
                .toList();

        String allPaths = createdEntities.stream()
                .map(this::entityPath)
                .collect(Collectors.joining(", "));

        // Generate CODE for all created entities
        StringBuilder codeBuilder = new StringBuilder();
        for (Object entity : createdEntities) {
            codeBuilder.append(generateEntityCodeString(entity));
        }

        report.recordEntityChange(CREATED, allPaths, createdEntities.getFirst().getClass(), null, null, codeBuilder.toString());
    }

    /**
     * Generates CODE showing all properties of an entity.
     */
    private void generateEntityCode(FabutReport report, Object entity) {
        report.addCode(() -> generateEntityCodeString(entity));
    }

    /**
     * Generates CODE string showing all properties of an entity.
     */
    private String generateEntityCodeString(Object entity) {
        final String className = getRealClass(entity.getClass()).getSimpleName();
        final List<Method> getMethods = getGetMethods(entity);
        StringBuilder sb = new StringBuilder();

        sb.append("\nCODE:\nassertObject(object");

        for (final Method method : getMethods) {
            final String fieldName = ReflectionUtil.getFieldNameOfGet(method);
            if (!isIgnoredField(entity.getClass(), fieldName)) {
                try {
                    final Object value = method.invoke(entity);
                    final String propertyPath = className + "." + upperUnderscored(fieldName);
                    if (value == null) {
                        sb.append(",\nisNull(").append(propertyPath).append(")");
                    } else if (value.getClass().isAssignableFrom(String.class)) {
                        sb.append(",\nvalue(").append(propertyPath).append(", \"").append(value).append("\")");
                    } else if (value.getClass().isEnum()) {
                        sb.append(",\nvalue(").append(propertyPath).append(", ").append(value.getClass().getSimpleName()).append(".").append(value).append(")");
                    } else if (isEntityType(value.getClass())) {
                        sb.append(",\nvalue(").append(propertyPath).append(", ").append(entityPath(value)).append(")");
                    } else {
                        sb.append(",\nvalue(").append(propertyPath).append(", ").append(value).append(")");
                    }
                } catch (Exception e) {
                    // Skip fields that can't be accessed
                }
            }
        }

        sb.append(");");
        return sb.toString();
    }

    /**
     * Generates a variable name suggestion for an entity (camelCase of class name).
     */
    private String varName(Object entity) {
        if (entity == null) return "entity";
        String simpleName = getRealClass(entity.getClass()).getSimpleName();
        return Character.toLowerCase(simpleName.charAt(0)) + simpleName.substring(1);
    }

    void assertDbSnapshotWithAfterState(
            final Set<?> beforeIds,
            final Set<?> afterIds,
            final Map<Object, CopyAssert> beforeEntities,
            final Map<Object, Object> afterEntities,
            final FabutReport report) {

        final Set<?> beforeIdsCopy = new HashSet<>(beforeIds);
        // does intersection between db snapshot and after db state
        beforeIdsCopy.retainAll(afterIds);

        // Sequential processing to properly track modifications
        for (final Object id : beforeIdsCopy) {
            CopyAssert copyAssert = beforeEntities.get(id);
            if (!copyAssert.isAsserted()) {
                Object beforeEntity = copyAssert.getEntity();
                Object afterEntity = afterEntities.get(id);

                FabutReport subReport = report.getSubReport(() -> "UPDATED: " + entityPath(beforeEntity));
                subReport.setAssertionContext(ENTITY_WITH_SNAPSHOT);
                assertObjects(subReport, beforeEntity, afterEntity, new ArrayList<>());
            }
        }
    }

    /** Thread pool size for parallel processing */
    private static final int PARALLEL_THRESHOLD = 50;

    /**
     * Check for concurrent processing threshold
     *
     * @param size Collection size to check
     * @return true if parallel processing should be used
     */
    private boolean shouldUseParallelProcessing(int size) {
        // Only use parallel processing in non-test environments
        // This preserves exact output format compatibility with existing tests
        final boolean sizeGreaterThenThrashodl = size > PARALLEL_THRESHOLD;
//        System.out.println("Using parallel processing:  " + sizeGreaterThenThrashodl);
        return  sizeGreaterThenThrashodl;
    }

}

record ObjectMethod(Object parent, String property) {}
